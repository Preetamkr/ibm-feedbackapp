

package com.ibm.mobileappbuilder.testfeedback20160930045915.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import ibmmobileappbuilder.ui.BaseDetailActivity;

/**
 * TestfeedbackDSSchemaItemFormActivity form activity
 */
public class TestfeedbackDSSchemaItemFormActivity extends BaseDetailActivity {
  	
  	@Override
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    
    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return TestfeedbackDSSchemaItemFormFragment.class;
    }
}


